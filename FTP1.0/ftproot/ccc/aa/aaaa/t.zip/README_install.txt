=========================================
Cisco Jabber for Windows 11.7.1 Installer
=========================================
  
CiscoJabber-Install-ffr.11-7-1.zip

Contains MSI for Build Number 11.7.1.46916
 - CiscoJabberSetup.msi
